﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Collections.Generic;

namespace InventoryTest
{
    class Start
    {
        static void Main(string[] args)
        {
            using (IWebDriver driver = new FirefoxDriver())
            {
                Actions action = new Actions(driver);

                driver.Url = "http://localhost:64744/";

                string title = driver.Title;

                if (title.Length > 0)
                    Console.WriteLine("Title of the page is : " + title);
                else
                    Console.WriteLine("Page has no Title");


                //look for all items in Menu
                //IWebElement Menu = driver.FindElement(By.Id("MainMenu"));
                //IList<IWebElement> SubMenuList = Menu.FindElements(By.TagName("li"));
                //IWebElement Menu;
                IList<IWebElement> SubMenuList;
                IWebElement SubMenu;
                //int iSubMenu = SubMenuList.Count;

                int iSubMenu = driver.FindElement(By.Id("MainMenu")).FindElements(By.TagName("li")).Count;


                for (int i = 1; i < iSubMenu; i++)
                {
                    //we need to click on main menu for submenus to appear
                    driver.FindElement(By.Id("MainMenu")).Click();
                    new WebDriverWait(driver, TimeSpan.FromSeconds(2));

                    SubMenuList = driver.FindElement(By.Id("MainMenu")).FindElements(By.TagName("li"));
                    SubMenu = SubMenuList[i];

                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("---------- " + SubMenu.Text + " " + new String('-', 33 - SubMenu.Text.Length));

                    switch (SubMenu.Text)
                    {
                        case "Proveedores":
                            ChecaProveedores(driver, SubMenu, i);
                            break;
                        case "Marcas":
                            ChecaMarcas(driver, SubMenu, i);
                            break;
                        case "Modelos":
                            ChecaModelos(driver, SubMenu, i);
                            break;
                        case "Items":
                            ChecaItems(driver, SubMenu, i);
                            break;
                        default:
                            break;
                    }
                    
                    
                    
                    
                    ////as this object changes everytime we change page, we need to reset it
                    ////Menu = driver.FindElement(By.Id("MainMenu"));
                    ////SubMenuList = Menu.FindElements(By.TagName("li"));
                    ////we need to click on main menu for submenus to appear
                    //driver.FindElement(By.Id("MainMenu")).Click();
                    //new WebDriverWait(driver, TimeSpan.FromSeconds(2));
                    ////then we can click on submenu
                    ////SubMenu = SubMenuList[i];
                    ////SubMenu.Click();
                    //driver.FindElement(By.Id("MainMenu")).FindElements(By.TagName("li"))[i].Click();
                    //Console.WriteLine((driver.FindElement(By.Id("MainMenu")).FindElements(By.TagName("li")))[i].Text + " OK");

                    //SubMenuList = driver.FindElement(By.Id("MainMenu")).FindElements(By.TagName("li"));
                    //SubMenu = (IWebElement)SubMenuList[i];
                    //string texto = SubMenu.Text;

                    //switch (texto)
                    //{
                    //    case "Proveedores":
                    //        driver.FindElement(By.Id("MainContent_lnkNuevoProveedor")).Click();
                    //        new WebDriverWait(driver, TimeSpan.FromSeconds(2));
                    //        driver.FindElement(By.Id("MainContent_txtNuevoProveedor")).Clear();
                    //        driver.FindElement(By.Id("MainContent_txtNuevoProveedor")).SendKeys("Nuevo Proveedor");
                    //        Console.WriteLine("input Nuevo Proveedor on MainContent_txtNuevoProveedor");
                    //        driver.FindElement(By.Id("MainContent_btnGuardarNuevoProveedor")).Click();
                    //        Console.WriteLine("Click on MainContent_btnGuardarNuevoProveedor");
                    //        new WebDriverWait(driver, TimeSpan.FromSeconds(7));
                    //        Console.WriteLine("MainContent_lblResultado.text: " + 
                    //            driver.FindElement(By.Id("MainContent_lblResultado")).Text);

                    //        break;
                    //    case "Marcas":

                    //        break;
                    //    case "Modelos":

                    //        break;
                    //    case "Items":

                    //        break;
                    //    default:
                    //        Console.WriteLine("Otros: " + driver.FindElement(By.Id("MainMenu")).FindElements(By.TagName("li"))[i].Text);
                    //        break;

                    //}
                        


                    new WebDriverWait(driver, TimeSpan.FromSeconds(2));
                }

                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("---------------------------------------------");
                FocusProcess(Process.GetCurrentProcess().ProcessName);
                Console.WriteLine("Process completed, Press ENTER to exit...");
                Console.ReadLine();
            }
        }

        protected static void ChecaProveedores(IWebDriver driver, IWebElement SubMenu, int i)
        {
            //Submenu
            SubMenu.Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            //Read current records
            Console.WriteLine("Current records: " +
                (driver.FindElement(By.Id("MainContent_gvListaProveedor")).FindElements(By.TagName("tr"))).Count);

            //Link Nuevo
            Console.WriteLine("");
            Console.WriteLine("----- Nuevo Proveedor");
            driver.FindElement(By.Id("MainContent_lnkNuevoProveedor")).Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            driver.FindElement(By.Id("MainContent_txtNuevoProveedor")).Clear();
            driver.FindElement(By.Id("MainContent_txtNuevoProveedor")).SendKeys("Nuevo Proveedor");
            Console.WriteLine("input \"Nuevo Proveedor\" on MainContent_txtNuevoProveedor");

            driver.FindElement(By.Id("MainContent_btnGuardarNuevoProveedor")).Click();
            Console.WriteLine("Click on MainContent_btnGuardarNuevoProveedor");
            new WebDriverWait(driver, TimeSpan.FromSeconds(7));
            Console.WriteLine("MainContent_lblResultado.text: " +
                driver.FindElement(By.Id("MainContent_lblResultado")).Text);

            //click on ListaProveedor again
            Console.WriteLine("");
            Console.WriteLine("----- Edit Proveedor");
            driver.FindElement(By.Id("MainMenu")).Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            driver.FindElement(By.Id("MainMenu")).FindElements(By.TagName("li"))[i].Click();

            int TotalRenglones = 0;
            //Read records again
            TotalRenglones = driver.FindElement(By.Id("MainContent_gvListaProveedor"))
                .FindElements(By.TagName("tr")).Count;
            Console.WriteLine("Current records: " + TotalRenglones);

            //Edit last one
            driver.FindElement(By.Id("MainContent_gvListaProveedor"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Edit")).Click();

            Console.WriteLine("Last Proveedor current value: " +
                driver.FindElement(By.Id("MainContent_gvListaProveedor_txtNombreProveedor_" + (TotalRenglones - 2).ToString())).GetAttribute("value"));

            driver.FindElement(By.Id("MainContent_gvListaProveedor_txtNombreProveedor_" + (TotalRenglones - 2).ToString()))
                .SendKeys(" modificado");

            driver.FindElement(By.Id("MainContent_gvListaProveedor"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Update")).Click();

            Console.WriteLine("Last Proveedor updated value: " +
                driver.FindElement(By.Id("MainContent_gvListaProveedor_lblNombreProveedor_" + (TotalRenglones - 2).ToString())).Text);

            Console.WriteLine("----- Delete Proveedor");
            Console.WriteLine("Current records: " +
                (driver.FindElement(By.Id("MainContent_gvListaProveedor")).FindElements(By.TagName("tr"))).Count);
            driver.FindElement(By.Id("MainContent_gvListaProveedor"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Delete")).Click();
            Console.WriteLine("After Delete records: " +
                (driver.FindElement(By.Id("MainContent_gvListaProveedor")).FindElements(By.TagName("tr"))).Count);
        }

        protected static void ChecaMarcas(IWebDriver driver, IWebElement SubMenu, int i)
        {
            //Submenu
            SubMenu.Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            //Read current records
            Console.WriteLine("Current records: " +
                (driver.FindElement(By.Id("MainContent_gvListaMarca")).FindElements(By.TagName("tr"))).Count);

            //Link Nueva
            Console.WriteLine("");
            Console.WriteLine("----- Nueva Marca");
            driver.FindElement(By.Id("MainContent_lnkNuevaMarca")).Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            SelectElement ddlProveedor = new SelectElement(driver.FindElement(By.Id("MainContent_ddlProveedor")));
            ddlProveedor.SelectByIndex(1);

            driver.FindElement(By.Id("MainContent_txtNuevaMarca")).Clear();
            driver.FindElement(By.Id("MainContent_txtNuevaMarca")).SendKeys("Nueva Marca");
            Console.WriteLine("input \"Nueva Marca\" on MainContent_txtNuevaMarca");

            driver.FindElement(By.Id("MainContent_btnGuardarNuevaMarca")).Click();
            Console.WriteLine("Click on MainContent_btnGuardarNuevaMarca");
            new WebDriverWait(driver, TimeSpan.FromSeconds(7));
            Console.WriteLine("MainContent_lblResultado.text: " +
                driver.FindElement(By.Id("MainContent_lblResultado")).Text);

            //click on ListaMarca again
            Console.WriteLine("");
            Console.WriteLine("----- Edit Marca");
            driver.FindElement(By.Id("MainMenu")).Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            driver.FindElement(By.Id("MainMenu")).FindElements(By.TagName("li"))[i].Click();

            int TotalRenglones = 0;
            //Read records again
            TotalRenglones = driver.FindElement(By.Id("MainContent_gvListaMarca"))
                .FindElements(By.TagName("tr")).Count;
            Console.WriteLine("Current records: " + TotalRenglones);

            //Edit last one
            driver.FindElement(By.Id("MainContent_gvListaMarca"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Edit")).Click();

            Console.WriteLine("Last Marca current value: " +
                driver.FindElement(By.Id("MainContent_gvListaMarca_txtNombreMarca_" + (TotalRenglones - 2).ToString())).GetAttribute("value"));

            driver.FindElement(By.Id("MainContent_gvListaMarca_txtNombreMarca_" + (TotalRenglones - 2).ToString()))
                .SendKeys(" modificado");

            driver.FindElement(By.Id("MainContent_gvListaMarca"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Update")).Click();

            Console.WriteLine("Last Marca updated value: " +
                driver.FindElement(By.Id("MainContent_gvListaMarca_lblNombreMarca_" + (TotalRenglones - 2).ToString())).Text);

            Console.WriteLine("----- Delete Marca");
            Console.WriteLine("Current records: " +
                (driver.FindElement(By.Id("MainContent_gvListaMarca")).FindElements(By.TagName("tr"))).Count);
            driver.FindElement(By.Id("MainContent_gvListaMarca"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Delete")).Click();
            Console.WriteLine("After Delete records: " +
                (driver.FindElement(By.Id("MainContent_gvListaMarca")).FindElements(By.TagName("tr"))).Count);
        }

        protected static void ChecaModelos(IWebDriver driver, IWebElement SubMenu, int i)
        {
            //Submenu
            SubMenu.Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            //Read current records
            Console.WriteLine("Current records: " +
                (driver.FindElement(By.Id("MainContent_gvListaModelo")).FindElements(By.TagName("tr"))).Count);

            //Link Nuevo
            Console.WriteLine("");
            Console.WriteLine("----- Nuevo Modelo");
            driver.FindElement(By.Id("MainContent_lnkNuevoModelo")).Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            SelectElement ddlMarca = new SelectElement(driver.FindElement(By.Id("MainContent_ddlMarca")));
            ddlMarca.SelectByIndex(1);

            driver.FindElement(By.Id("MainContent_txtNuevoModelo")).Clear();
            driver.FindElement(By.Id("MainContent_txtNuevoModelo")).SendKeys("Nuevo Modelo");
            Console.WriteLine("input \"Nuevo Modelo\" on MainContent_txtNuevoModelo");

            driver.FindElement(By.Id("MainContent_btnGuardarNuevoModelo")).Click();
            Console.WriteLine("Click on MainContent_btnGuardarNuevoModelo");
            new WebDriverWait(driver, TimeSpan.FromSeconds(7));
            Console.WriteLine("MainContent_lblResultado.text: " +
                driver.FindElement(By.Id("MainContent_lblResultado")).Text);

            //click on ListaModelo again
            Console.WriteLine("");
            Console.WriteLine("----- Edit Modelo");
            driver.FindElement(By.Id("MainMenu")).Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            driver.FindElement(By.Id("MainMenu")).FindElements(By.TagName("li"))[i].Click();

            int TotalRenglones = 0;
            //Read records again
            TotalRenglones = driver.FindElement(By.Id("MainContent_gvListaModelo"))
                .FindElements(By.TagName("tr")).Count;
            Console.WriteLine("Current records: " + TotalRenglones);

            //Edit last one
            driver.FindElement(By.Id("MainContent_gvListaModelo"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Edit")).Click();

            Console.WriteLine("Last Modelo current value: " +
                driver.FindElement(By.Id("MainContent_gvListaModelo_txtNombreModelo_" + (TotalRenglones - 2).ToString())).GetAttribute("value"));

            driver.FindElement(By.Id("MainContent_gvListaModelo_txtNombreModelo_" + (TotalRenglones - 2).ToString()))
                .SendKeys(" modificado");

            driver.FindElement(By.Id("MainContent_gvListaModelo"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Update")).Click();

            Console.WriteLine("Last Modelo updated value: " +
                driver.FindElement(By.Id("MainContent_gvListaModelo_lblNombreModelo_" + (TotalRenglones - 2).ToString())).Text);

            Console.WriteLine("----- Delete Modelo");
            Console.WriteLine("Current records: " +
                (driver.FindElement(By.Id("MainContent_gvListaModelo")).FindElements(By.TagName("tr"))).Count);
            driver.FindElement(By.Id("MainContent_gvListaModelo"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Delete")).Click();
            Console.WriteLine("After Delete records: " +
                (driver.FindElement(By.Id("MainContent_gvListaModelo")).FindElements(By.TagName("tr"))).Count);
        }

        protected static void ChecaItems(IWebDriver driver, IWebElement SubMenu, int i)
        {
            //Submenu
            SubMenu.Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            //Read current records
            Console.WriteLine("Current records: " +
                (driver.FindElement(By.Id("MainContent_gvListaItem")).FindElements(By.TagName("tr"))).Count);

            //Link Nuevo
            Console.WriteLine("");
            Console.WriteLine("----- Nuevo Item");
            driver.FindElement(By.Id("MainContent_lnkNuevoItem")).Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            SelectElement ddlProveedor = new SelectElement(driver.FindElement(By.Id("MainContent_ddlProveedor")));
            ddlProveedor.SelectByIndex(1);

            SelectElement ddlMarca = new SelectElement(driver.FindElement(By.Id("MainContent_ddlMarca")));
            ddlMarca.SelectByIndex(1);

            SelectElement ddlModelo = new SelectElement(driver.FindElement(By.Id("MainContent_ddlModelo")));
            ddlModelo.SelectByIndex(1);

            driver.FindElement(By.Id("MainContent_txtNuevoItem")).Clear();
            driver.FindElement(By.Id("MainContent_txtNuevoItem")).SendKeys("Nuevo Item");
            Console.WriteLine("input \"Nuevo Item\" on MainContent_txtNuevoItem");

            driver.FindElement(By.Id("MainContent_btnGuardarNuevoItem")).Click();
            Console.WriteLine("Click on MainContent_btnGuardarNuevoItem");
            new WebDriverWait(driver, TimeSpan.FromSeconds(7));
            Console.WriteLine("MainContent_lblResultado.text: " +
                driver.FindElement(By.Id("MainContent_lblResultado")).Text);

            //click on ListaItem again
            Console.WriteLine("");
            Console.WriteLine("----- Edit Item");
            driver.FindElement(By.Id("MainMenu")).Click();
            new WebDriverWait(driver, TimeSpan.FromSeconds(2));

            driver.FindElement(By.Id("MainMenu")).FindElements(By.TagName("li"))[i].Click();

            int TotalRenglones = 0;
            //Read records again
            TotalRenglones = driver.FindElement(By.Id("MainContent_gvListaItem"))
                .FindElements(By.TagName("tr")).Count;
            Console.WriteLine("Current records: " + TotalRenglones);

            //Edit last one
            driver.FindElement(By.Id("MainContent_gvListaItem"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Edit")).Click();

            Console.WriteLine("Last Item current value: " +
                driver.FindElement(By.Id("MainContent_gvListaItem_txtNombreItem_" + (TotalRenglones - 2).ToString())).GetAttribute("value"));

            driver.FindElement(By.Id("MainContent_gvListaItem_txtNombreItem_" + (TotalRenglones - 2).ToString()))
                .SendKeys(" modificado");

            driver.FindElement(By.Id("MainContent_gvListaItem"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Update")).Click();

            Console.WriteLine("Last Item updated value: " +
                driver.FindElement(By.Id("MainContent_gvListaItem_lblNombreItem_" + (TotalRenglones - 2).ToString())).Text);

            Console.WriteLine("----- Delete Item");
            Console.WriteLine("Current records: " +
                (driver.FindElement(By.Id("MainContent_gvListaItem")).FindElements(By.TagName("tr"))).Count);
            driver.FindElement(By.Id("MainContent_gvListaItem"))
                .FindElements(By.TagName("tr"))[TotalRenglones - 1]
                .FindElement(By.LinkText("Delete")).Click();
            Console.WriteLine("After Delete records: " +
                (driver.FindElement(By.Id("MainContent_gvListaItem")).FindElements(By.TagName("tr"))).Count);
        }

        [DllImport("user32.dll")]
        public static extern bool ShowWindowAsync(HandleRef hWnd, int nCmdShow);
        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr WindowHandle);

        public const int SW_RESTORE = 9;

        protected static void FocusProcess(string procName)
        {
            Process[] objProcesses = System.Diagnostics.Process.GetProcessesByName(procName);
            if (objProcesses.Length > 0)
            {
                IntPtr hWnd = IntPtr.Zero;
                hWnd = objProcesses[0].MainWindowHandle;
                ShowWindowAsync(new HandleRef(null, hWnd), SW_RESTORE);
                SetForegroundWindow(objProcesses[0].MainWindowHandle);
            }
        }
    }
}
