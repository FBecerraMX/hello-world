﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Inventory.item
{
    public partial class NuevoItem : System.Web.UI.Page
    {
        UST_InventoryEntities db = new UST_InventoryEntities();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindddlProveedor();
            }
        }

        protected void btnGuardarNuevoItem_Click(object sender, EventArgs e)
        {
            lblResultado.Visible = true;
            try
            {
                db.Item.AddObject(new Item {
                    IDProveedor = int.Parse(ddlProveedor.SelectedValue),
                    IDMarca = int.Parse(ddlMarca.SelectedValue),
                    IDModelo = int.Parse(ddlModelo.SelectedValue),
                    NombreItem = txtNuevoItem.Text
                });
                db.SaveChanges();
                lblResultado.Text = "Se guardo correctamente la informacion";
            }
            catch (Exception ex)
            {
                lblResultado.Text = ex.Message;
            }
        }

        protected void BindddlProveedor()
        {
            var Proveedor = (from m in db.Proveedor
                             select new { m.IDProveedor, m.NombreProveedor }).ToList();
            ddlProveedor.DataValueField = "IDProveedor";
            ddlProveedor.DataTextField = "NombreProveedor";
            ddlProveedor.DataSource = Proveedor;
            ddlProveedor.DataBind();
            ddlProveedor.Items.Insert(0, new ListItem("- Seleccione -", "0"));
        }

        protected void BindddlMarca(int IDProveedor)
        {
            var marca = (from m in db.Marca
                         where m.IDProveedor == IDProveedor
                         select new { m.IDMarca, m.NombreMarca }).ToList();
            ddlMarca.DataValueField = "IDMarca";
            ddlMarca.DataTextField = "NombreMarca";
            ddlMarca.DataSource = marca;
            ddlMarca.DataBind();
            ddlMarca.Items.Insert(0, new ListItem("- Seleccione -", "0"));
        }

        protected void BindddlModelo(int IDMarca)
        {
            var Modelo = (from m in db.Modelo
                          where m.IDMarca == IDMarca
                         select new { m.IDModelo, m.NombreModelo }).ToList();
            ddlModelo.DataValueField = "IDModelo";
            ddlModelo.DataTextField = "NombreModelo";
            ddlModelo.DataSource = Modelo;
            ddlModelo.DataBind();
            ddlModelo.Items.Insert(0, new ListItem("- Seleccione -", "0"));
        }

        protected void ddlProveedor_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindddlMarca(int.Parse(ddlProveedor.SelectedValue));
        }

        protected void ddlMarca_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindddlModelo(int.Parse(ddlMarca.SelectedValue));
        }
    }
}