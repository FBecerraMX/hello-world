﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Inventory.item
{
    public partial class ListaItem : System.Web.UI.Page
    {
        UST_InventoryEntities db = new UST_InventoryEntities();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (db.Item.Count() > 0)
                {
                    Bind();
                    lblTituloItem.Text = "Listado de Items";
                }
                else
                {
                    lblTituloItem.Text = "No se encontro informacion";
                }
            }
        }

        protected void gvListaItem_Edit(object sender, GridViewEditEventArgs e)
        {
            gvListaItem.EditIndex = e.NewEditIndex;
            Bind();
        }

        protected void gvListaItem_Update(object sender, GridViewUpdateEventArgs e)
        {
            int IDCambiar = int.Parse(gvListaItem.DataKeys[e.RowIndex].Values["IDItem"].ToString());
            Item ItemCambiar = (from i in db.Item
                                where i.IDItem == IDCambiar
                                select i).FirstOrDefault();
            TextBox txt = (TextBox)gvListaItem.Rows[e.RowIndex].FindControl("txtNombreItem");
            ItemCambiar.NombreItem = txt.Text;
            db.SaveChanges();
            gvListaItem.EditIndex = -1;
            Bind();
        }

        protected void gvListaItem_Cancel(object sender, GridViewCancelEditEventArgs e)
        {
            gvListaItem.EditIndex = -1;
            Bind();
        }

        protected void gvListaItem_Delete(object sender, GridViewDeleteEventArgs e)
        {
            int IDBorrar = int.Parse(gvListaItem.DataKeys[e.RowIndex].Values["IDItem"].ToString());
            var ItemBorrar = (from i in db.Item
                              where i.IDItem == IDBorrar
                              select i).FirstOrDefault();

            db.Item.DeleteObject(ItemBorrar);
            db.SaveChanges();
            Bind();
        }

        protected void Bind()
        {
            var r = (from i in db.Item
                     join ma in db.Marca on i.IDMarca equals ma.IDMarca
                     join mo in db.Modelo on i.IDModelo equals mo.IDModelo
                     join p in db.Proveedor on i.IDProveedor equals p.IDProveedor
                     select new
                     {
                         IDItem = i.IDItem,
                         NombreMarca = ma.NombreMarca,
                         NombreModelo = mo.NombreModelo,
                         NombreProveedor = p.NombreProveedor,
                         NombreItem = i.NombreItem
                     });

            gvListaItem.DataSource = r.ToList();
            gvListaItem.DataBind();
        }
    }
}