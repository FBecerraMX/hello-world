﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Inventory.modelo
{
    public partial class ListaModelo : System.Web.UI.Page
    {
        UST_InventoryEntities db = new UST_InventoryEntities();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (db.Modelo.Count() > 0)
                {
                    Bind();
                    lblTituloModelo.Text = "Listado de Modelos";
                }
                else
                {
                    lblTituloModelo.Text = "No se encontro informacion";
                }
            }
        }

        protected void gvListaModelo_Edit(object sender, GridViewEditEventArgs e)
        {
            gvListaModelo.EditIndex = e.NewEditIndex;
            Bind();
        }

        protected void gvListaModelo_Update(object sender, GridViewUpdateEventArgs e)
        {
            int IDCambiar = int.Parse(gvListaModelo.DataKeys[e.RowIndex].Values["IDModelo"].ToString());
            Modelo ModeloCambiar = (from m in db.Modelo
                                    where m.IDModelo == IDCambiar
                                    select m).FirstOrDefault();
            TextBox txt = (TextBox)gvListaModelo.Rows[e.RowIndex].FindControl("txtNombreModelo");
            ModeloCambiar.NombreModelo = txt.Text;
            db.SaveChanges();
            gvListaModelo.EditIndex = -1;
            Bind();
        }

        protected void gvListaModelo_Cancel(object sender, GridViewCancelEditEventArgs e)
        {
            gvListaModelo.EditIndex = -1;
            Bind();
        }

        protected void gvListaModelo_Delete(object sender, GridViewDeleteEventArgs e)
        {
            int IDBorrar = int.Parse(gvListaModelo.DataKeys[e.RowIndex].Values["IDModelo"].ToString());
            var ModeloBorrar = (from m in db.Modelo
                               where m.IDModelo == IDBorrar
                               select m).FirstOrDefault();

            db.Modelo.DeleteObject(ModeloBorrar);
            db.SaveChanges();
            Bind();
        }

        protected void Bind()
        {
            gvListaModelo.DataSource = db.Modelo;
            gvListaModelo.DataBind();
        }
    }
}