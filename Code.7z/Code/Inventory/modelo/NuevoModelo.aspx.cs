﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Inventory.modelo
{
    public partial class NuevoModelo : System.Web.UI.Page
    {
        UST_InventoryEntities db = new UST_InventoryEntities();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindddlMarca();
            }
        }

        protected void btnGuardarNuevoModelo_Click(object sender, EventArgs e)
        {
            lblResultado.Visible = true;
            try
            {
                db.Modelo.AddObject(new Modelo { IDMarca = int.Parse(ddlMarca.SelectedValue), NombreModelo = txtNuevoModelo.Text });
                db.SaveChanges();
                lblResultado.Text = "Se guardo correctamente la informacion";
                lblResultado.Visible = true;
            }
            catch (Exception ex)
            {
                lblResultado.Text = ex.Message;
            }
        }

        protected void BindddlMarca()
        {
            var marca = (from m in db.Marca
                            select new { m.IDMarca, m.NombreMarca }).ToList();
            ddlMarca.DataValueField = "IDMarca";
            ddlMarca.DataTextField = "NombreMarca";
            ddlMarca.DataSource = marca;
            ddlMarca.DataBind();
            ddlMarca.Items.Insert(0, new ListItem("- Seleccione -", "0"));
        }
    }
}