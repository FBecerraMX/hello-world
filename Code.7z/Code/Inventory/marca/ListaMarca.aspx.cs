﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Inventory.marca
{
    public partial class ListaMarca : System.Web.UI.Page
    {
        UST_InventoryEntities db = new UST_InventoryEntities();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (db.Marca.Count() > 0)
                {
                    Bind();
                    lblTituloMarca.Text = "Listado de Marcas";
                }
                else
                {
                    lblTituloMarca.Text = "No se encontro informacion";
                }
            }
        }

        protected void gvListaMarca_Edit(object sender, GridViewEditEventArgs e)
        {
            gvListaMarca.EditIndex = e.NewEditIndex;
            Bind();
        }

        protected void gvListaMarca_Update(object sender, GridViewUpdateEventArgs e)
        {
            int IDCambiar = int.Parse(gvListaMarca.DataKeys[e.RowIndex].Values["IDMarca"].ToString());
            Marca MarcaCambiar = (from m in db.Marca
                                  where m.IDMarca == IDCambiar
                                  select m).FirstOrDefault();
            TextBox txt = (TextBox)gvListaMarca.Rows[e.RowIndex].FindControl("txtNombreMarca");
            MarcaCambiar.NombreMarca = txt.Text;
            db.SaveChanges();
            gvListaMarca.EditIndex = -1;
            Bind();
        }

        protected void gvListaMarca_Cancel(object sender, GridViewCancelEditEventArgs e)
        {
            gvListaMarca.EditIndex = -1;
            Bind();
        }
        
        protected void gvListaMarca_Delete(object sender, GridViewDeleteEventArgs e)
        {
            int IDBorrar = int.Parse(gvListaMarca.DataKeys[e.RowIndex].Values["IDMarca"].ToString());
            var MarcaBorrar = (from m in db.Marca
                               where m.IDMarca == IDBorrar
                               select m).FirstOrDefault();

            db.Marca.DeleteObject(MarcaBorrar);
            db.SaveChanges();
            Bind();
        }

        protected void Bind()
        {
            gvListaMarca.DataSource = db.Marca;
            gvListaMarca.DataBind();
        }
    }
}