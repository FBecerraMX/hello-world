﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Inventory.marca
{
    public partial class NuevaMarca : System.Web.UI.Page
    {
        UST_InventoryEntities db = new UST_InventoryEntities();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindddlProveedor();
            }
        }

        protected void btnGuardarNuevaMarca_Click(object sender, EventArgs e)
        {
            lblResultado.Visible = true;
            try
            {
                db.Marca.AddObject(new Marca { IDProveedor = int.Parse(ddlProveedor.SelectedValue), NombreMarca = txtNuevaMarca.Text });
                db.SaveChanges();
                lblResultado.Text = "Se guardo correctamente la informacion";
            }
            catch (Exception ex)
            {
                lblResultado.Text = ex.Message;
            }
        }

        protected void BindddlProveedor()
        {
            var Proveedor = (from m in db.Proveedor
                         select new { m.IDProveedor, m.NombreProveedor }).ToList();
            ddlProveedor.DataValueField = "IDProveedor";
            ddlProveedor.DataTextField = "NombreProveedor";
            ddlProveedor.DataSource = Proveedor;
            ddlProveedor.DataBind();
            ddlProveedor.Items.Insert(0, new ListItem("- Seleccione -", "0"));
        }
 
    }
}