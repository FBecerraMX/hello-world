﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Inventory.proveedor
{
    public partial class NuevoProveedor : System.Web.UI.Page
    {
        UST_InventoryEntities db = new UST_InventoryEntities();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGuardarNuevoProveedor_Click(object sender, EventArgs e)
        {
            lblResultado.Visible = true;
            try
            {
                db.Proveedor.AddObject(new Proveedor { NombreProveedor = txtNuevoProveedor.Text });
                db.SaveChanges();
                lblResultado.Text = "Se guardo correctamente la informacion";
                lblResultado.Visible = true;
            }
            catch (Exception ex)
            {
                lblResultado.Text = ex.Message;
            }
        }
    }
}