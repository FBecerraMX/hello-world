﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Inventory.proveedor
{
    public partial class ListaProveedor : System.Web.UI.Page
    {
        UST_InventoryEntities db = new UST_InventoryEntities();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (db.Proveedor.Count() > 0)
                {
                    Bind();
                    lblTituloProveedor.Text = "Listado de Proveedores";
                }
                else
                {
                    lblTituloProveedor.Text = "No se encontro informacion";
                }
            }
        }

        protected void gvListaProveedor_Edit(object sender, GridViewEditEventArgs e)
        {
            gvListaProveedor.EditIndex = e.NewEditIndex;
            Bind();
        }

        protected void gvListaProveedor_Update(object sender, GridViewUpdateEventArgs e)
        {
            int IDCambiar = int.Parse(gvListaProveedor.DataKeys[e.RowIndex].Values["IDProveedor"].ToString());
            Proveedor ProveedorCambiar = (from m in db.Proveedor
                                          where m.IDProveedor == IDCambiar
                                          select m).FirstOrDefault();
            TextBox txt = (TextBox)gvListaProveedor.Rows[e.RowIndex].FindControl("txtNombreProveedor");
            ProveedorCambiar.NombreProveedor = txt.Text;
            db.SaveChanges();
            gvListaProveedor.EditIndex = -1;
            Bind();
        }

        protected void gvListaProveedor_Cancel(object sender, GridViewCancelEditEventArgs e)
        {
            gvListaProveedor.EditIndex = -1;
            Bind();
        }

        protected void gvListaProveedor_Delete(object sender, GridViewDeleteEventArgs e)
        {
            int IDBorrar = int.Parse(gvListaProveedor.DataKeys[e.RowIndex].Values["IDProveedor"].ToString());
            var ProveedorBorrar = (from p in db.Proveedor
                                   where p.IDProveedor == IDBorrar
                                   select p).First();

            db.Proveedor.DeleteObject(ProveedorBorrar);
            db.SaveChanges();
            Bind();
        }

        protected void Bind()
        {
            gvListaProveedor.DataSource = db.Proveedor;
            gvListaProveedor.DataBind();
        }
    }
}